from setuptools import setup, find_packages


setup(
    name="BetheFluid",
    version="0.1",
    description='Python package for solving GHD equations',
    author='Antoni Lis',
    packages=['BetheFluid'],
    zip_safe=False
)